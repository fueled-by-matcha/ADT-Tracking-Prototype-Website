# APT-Tracking-Prototype-Website
So far, HTML files added
-Form implemented for add_APT, need to add the verification stuff (can likely javaScript that, check to make sure required 
fields aren't left blank/enable it in form
-Search by implemented, need to do the search() function
-home page created, just have buttons for now
Needed - CSS, more JavaScript, and stuff to make it nice
